﻿namespace CrediteBancareApp
{


    partial class CrediteBancareDataSet
    {
        partial class CrediteDataTable
        {
        }
    }
}
