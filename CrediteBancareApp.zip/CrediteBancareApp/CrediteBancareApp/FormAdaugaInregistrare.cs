﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CrediteBancareApp
{
    public partial class FormAdaugaInregistrare : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\CrediteBancare.mdf;Integrated Security=True";

        public FormAdaugaInregistrare()
        {
            InitializeComponent();
            this.Text = "Adaugare Client";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string queryClient = "INSERT INTO Clienti (Nume, Prenume, Email, Telefon, Data_Nasterii) VALUES (@Nume, @Prenume, @Email, @Telefon, @DataNasterii); SELECT SCOPE_IDENTITY();";
                    SqlCommand cmdClient = new SqlCommand(queryClient, conn);
                    cmdClient.Parameters.AddWithValue("@Nume", textBox1.Text);
                    cmdClient.Parameters.AddWithValue("@Prenume", textBox2.Text);
                    cmdClient.Parameters.AddWithValue("@Email", textBox3.Text);
                    cmdClient.Parameters.AddWithValue("@Telefon", textBox4.Text);
                    cmdClient.Parameters.AddWithValue("@DataNasterii", DateTime.Parse(textBox5.Text));

                    int newClientID = Convert.ToInt32(cmdClient.ExecuteScalar());

                    string queryCredit = "INSERT INTO Credite (ID_Client, Suma, Dobinda, Data_Acordarii, Data_Scadenta) VALUES (@ID_Client, @Suma, @Dobinda, @DataAcordarii, @DataScadenta)";
                    SqlCommand cmdCredit = new SqlCommand(queryCredit, conn);
                    cmdCredit.Parameters.AddWithValue("@ID_Client", newClientID);
                    cmdCredit.Parameters.AddWithValue("@Suma", decimal.Parse(textBox6.Text));
                    cmdCredit.Parameters.AddWithValue("@Dobinda", float.Parse(textBox7.Text));
                    cmdCredit.Parameters.AddWithValue("@DataAcordarii", DateTime.Parse(textBox8.Text));
                    cmdCredit.Parameters.AddWithValue("@DataScadenta", DateTime.Parse(textBox9.Text));

                    cmdCredit.ExecuteNonQuery();
                    MessageBox.Show("Înregistrarea a fost adăugată cu succes!", "Succes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Eroare la adăugare: " + ex.Message, "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}