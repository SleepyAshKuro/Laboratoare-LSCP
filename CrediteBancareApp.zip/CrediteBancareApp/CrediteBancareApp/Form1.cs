﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CrediteBancareApp
{

    public partial class Form1 : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\CrediteBancare.mdf;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            this.Text = "Credite Bancare";
            LoadData();
            LoadInterogari();
        }

        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Clienti", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void LoadInterogari()
        {
            comboBox1.Items.Add("Clienți fără credite");
            comboBox1.Items.Add("Clienți cu credite");
            comboBox1.Items.Add("Clienți cu dobândă < 10");
            comboBox1.Items.Add("Clienți cu dobândă > 10");
            comboBox1.Items.Add("Credite cu suma > 10000");
            comboBox1.Items.Add("Credite cu suma < 10000");
            comboBox1.Items.Add("Credite achitate complet");
            comboBox1.Items.Add("Credite neachitate");
        }

        private void clientiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.clientiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.crediteBancareDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'crediteBancareDataSet.Credite' table. You can move, or remove it, as needed.
            this.crediteTableAdapter.Fill(this.crediteBancareDataSet.Credite);
            // TODO: This line of code loads data into the 'crediteBancareDataSet.Clienti' table. You can move, or remove it, as needed.
            this.clientiTableAdapter.Fill(this.crediteBancareDataSet.Clienti);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Selectați o interogare!", "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "";
            switch (comboBox1.SelectedItem.ToString())
            {
                case "Clienți fără credite":
                    query = "SELECT * FROM Clienti WHERE ID_Client NOT IN (SELECT ID_Client FROM Credite)";
                    break;
                case "Clienți cu credite":
                    query = "SELECT DISTINCT Clienti.* FROM Clienti INNER JOIN Credite ON Clienti.ID_Client = Credite.ID_Client";
                    break;
                case "Clienți cu dobândă < 10":
                    query = "SELECT DISTINCT Clienti.* FROM Clienti INNER JOIN Credite ON Clienti.ID_Client = Credite.ID_Client WHERE Dobinda < 10";
                    break;
                case "Clienți cu dobândă > 10":
                    query = "SELECT DISTINCT Clienti.* FROM Clienti INNER JOIN Credite ON Clienti.ID_Client = Credite.ID_Client WHERE Dobinda > 10";
                    break;
                case "Credite cu suma > 10000":
                    query = "SELECT * FROM Credite WHERE Suma > 10000";
                    break;
                case "Credite cu suma < 10000":
                    query = "SELECT * FROM Credite WHERE Suma < 10000";
                    break;
                case "Credite achitate complet":
                    query = "SELECT * FROM Credite WHERE Data_Scadenta < GETDATE()";
                    break;
                case "Credite neachitate":
                    query = "SELECT * FROM Credite WHERE Data_Scadenta >= GETDATE()";
                    break;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormAdaugaInregistrare form = new FormAdaugaInregistrare();
            form.ShowDialog();
            LoadData();
        }
    }
}